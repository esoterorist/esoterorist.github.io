// ===========================================================
// Footer year
// ===========================================================
document.getElementById('year').textContent = new Date().getFullYear();

// ===========================================================
// Connecting spine: fills as you scroll through <main>
// ===========================================================
const spineFill = document.getElementById('spineFill');
const main = document.querySelector('main');

function updateSpine(){
  if (!spineFill || !main) return;
  const rect = main.getBoundingClientRect();
  const totalHeight = main.offsetHeight - window.innerHeight;
  const scrolled = Math.min(Math.max(-rect.top, 0), totalHeight);
  const percent = totalHeight > 0 ? (scrolled / totalHeight) * 100 : 0;
  spineFill.style.height = percent + '%';
}

window.addEventListener('scroll', updateSpine, { passive: true });
window.addEventListener('resize', updateSpine);
updateSpine();

// ===========================================================
// Light up each panel's node dot when it enters view
// ===========================================================
const panels = document.querySelectorAll('[data-node]');

if ('IntersectionObserver' in window){
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      entry.target.classList.toggle('is-active', entry.isIntersecting);
    });
  }, { threshold: 0.35 });

  panels.forEach(panel => observer.observe(panel));
} else {
  // fallback: just mark everything active
  panels.forEach(panel => panel.classList.add('is-active'));
}

// ===========================================================
// Copy email to clipboard
// ===========================================================
const copyBtn = document.getElementById('copyBtn');
const emailText = document.getElementById('emailText');

if (copyBtn && emailText){
  copyBtn.addEventListener('click', async () => {
    try{
      await navigator.clipboard.writeText(emailText.textContent.trim());
      const original = copyBtn.textContent;
      copyBtn.textContent = 'Copied';
      copyBtn.classList.add('copied');
      setTimeout(() => {
        copyBtn.textContent = original;
        copyBtn.classList.remove('copied');
      }, 1600);
    } catch (err){
      // Clipboard API unavailable — fall back to selecting the text
      const range = document.createRange();
      range.selectNode(emailText);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
    }
  });
}
