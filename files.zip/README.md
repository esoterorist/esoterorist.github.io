# Your Portfolio Site

A single-page portfolio: socials + email, an art gallery, a music list, and
a writing/projects section — styled like a hand-drawn schematic. A line
traces down the page connecting each section as you scroll.

No build step, no dependencies. Just HTML, CSS, and JS.

```
portfolio-site/
├── index.html        the whole page
├── css/style.css      all styling (edit tokens at the top for colors/fonts)
├── js/script.js        scroll spine, active-section dots, copy-email button
├── images/             placeholder art thumbnails (SVG) — swap these out
└── README.md
```

## 1. Edit your content

Everything you need to change is marked with `<!-- EDIT: ... -->` comments
in `index.html`. In short:

- **Name & tagline** — top of the `<body>`, in the hero section.
- **Email & social links** — search for `mailto:you@example.com` and
  `href="#"` in the icon rows (there are two: hero and contact) and swap
  in your real links.
- **Art** — in the `#art` section, each piece is a `<figure class="art-card">`.
  Replace `images/placeholder-art-*.svg` with your own image files (drop
  them in `images/` and update the `src`), and edit the caption/year.
  Duplicate the block to add more pieces.
- **Music** — in the `#music` section, each `<li class="track">` is one
  track. Point `track-link` at wherever the track lives (Spotify,
  SoundCloud, Bandcamp, YouTube). If you'd rather embed an actual player,
  there's a commented-out Spotify iframe example right below the list —
  delete the `<ul class="track-list">` block and uncomment that instead.
- **Writing/projects** — same pattern in `#writing`, one `<li class="project">`
  per item.
- **Page title & description** — the `<title>` and `<meta name="description">`
  tags at the top of `<head>`.

## 2. Preview it locally

You don't need a server for basic edits — just double-click `index.html`
to open it in a browser. If you want the copy-to-clipboard button to work
exactly like it will when deployed, run a tiny local server instead:

```bash
cd portfolio-site
python3 -m http.server 8000
# then open http://localhost:8000 in your browser
```

## 3. Host it free on GitHub Pages

1. Create a new GitHub repository. If you want it at
   `https://yourusername.github.io` directly, name the repo exactly
   `yourusername.github.io`. Otherwise any name works and it'll be hosted
   at `https://yourusername.github.io/repo-name`.
2. Push this folder's contents to the repo (from inside `portfolio-site/`):
   ```bash
   git init
   git add .
   git commit -m "First version of my site"
   git branch -M main
   git remote add origin https://github.com/yourusername/your-repo.git
   git push -u origin main
   ```
3. On GitHub, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to "Deploy from a branch",
   pick branch **main** and folder **/ (root)**, then **Save**.
5. Wait a minute or two — GitHub will give you a live URL at the top of
   that Pages settings screen. That's your site.

Any time you push new commits to `main`, the live site updates
automatically within a minute or so.

### Using a custom domain (optional)

If you own a domain, add a `CNAME` file at the root of the repo containing
just your domain name (e.g. `yourname.com`), then point your domain's DNS
at GitHub Pages following
[GitHub's custom domain guide](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site).

## Notes on the design

- The vertical line down the left edge (desktop only) fills in as you
  scroll, and the dot next to each section lights up cobalt blue when
  that section is active — a small nod to the "everything's connected"
  diagram idea.
- Colors, fonts, and spacing are all defined as CSS custom properties at
  the top of `css/style.css` under `:root` — change those to retheme the
  whole site without touching the rest of the file.
- The layout is responsive; the connecting line and dots hide below
  900px width to keep things simple on mobile.
